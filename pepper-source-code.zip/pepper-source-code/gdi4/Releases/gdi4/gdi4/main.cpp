#include <windows.h>
#include <cmath>
#include <cstdlib>

COLORREF RainbowColor(double t, int y)
{
    return RGB(
        (int)(128 + 127 * sin(t + y * 0.02)),
        (int)(128 + 127 * sin(t + y * 0.02 + 2.0)),
        (int)(128 + 127 * sin(t + y * 0.02 + 4.0))
    );
}

int main()
{
    ShowWindow(GetConsoleWindow(), SW_HIDE);

    HDC hdc = GetDC(NULL);

    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    HICON icons[4];

    icons[0] = LoadIcon(NULL, IDI_ERROR);
    icons[1] = LoadIcon(NULL, IDI_WARNING);
    icons[2] = LoadIcon(NULL, IDI_INFORMATION);
    icons[3] = LoadIcon(NULL, IDI_QUESTION);

    double t = 0;

    while(true)
    {
        // RAINBOW BACKGROUND
        for(int y = 0; y < sh; y += 12)
        {
            HBRUSH brush =
                CreateSolidBrush(
                    RainbowColor(t, y)
                );

            RECT r =
            {
                0,
                y,
                sw,
                y + 12
            };

            FillRect(hdc, &r, brush);

            DeleteObject(brush);
        }

        // SCREEN WAVES
        for(int y = 0; y < sh; y += 2)
        {
            int wave =
                (int)(
                    sin(y * 0.02 + t)
                    * 30
                );

            BitBlt(
                hdc,
                wave,
                y,
                sw,
                2,
                hdc,
                0,
                y,
                SRCCOPY
            );
        }

        // HUGE WINDOWS ICONS
        for(int i = 0; i < 50; i++)
        {
            DrawIconEx(
                hdc,
                rand() % sw,
                rand() % sh,
                icons[rand() % 4],
                256,
                256,
                0,
                NULL,
                DI_NORMAL
            );
        }

        // EXTRA COLORFUL CIRCLES
        for(int i = 0; i < 10; i++)
        {
            HBRUSH brush =
                CreateSolidBrush(
                    RGB(
                        rand() % 256,
                        rand() % 256,
                        rand() % 256
                    )
                );

            SelectObject(hdc, brush);

            int x = rand() % sw;
            int y = rand() % sh;
            int s = rand() % 300 + 50;

            Ellipse(
                hdc,
                x,
                y,
                x + s,
                y + s
            );

            DeleteObject(brush);
        }

        t += 0.1;

        Sleep(1);
    }

    ReleaseDC(NULL, hdc);

    return 0;
}
