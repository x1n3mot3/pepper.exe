██████╗ ███████╗██████╗ ██████╗ ███████╗██████╗ 
██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝██╔══██╗
██████╔╝█████╗  ██████╔╝██████╔╝█████╗  ██████╔╝
██╔═══╝ ██╔══╝  ██╔═══╝ ██╔═══╝ ██╔══╝  ██╔══██╗
██║     ███████╗██║     ██║     ███████╗██║  ██║
╚═╝     ╚══════╝╚═╝     ╚═╝     ╚══════╝╚═╝  ╚═╝
pepper.exe by x1n3mot3, xnine and FuxiProductionsXP

A malware with 7 payloads

Date created: 09/20/2026

Damage rate: Destructive++ (for safety version Low++)

Made with: Visual Studio Code, Vbs To Exe and VBScript.

Virus mode: Destructive GDI Malware/Trojan

---------------------------------------------------------------------------------------------------------------------------------------
Shoutout and thanks to xnine and FuxiProductionsXP!

Some of the gdi effects made by x1n3mot3

Rest of the gdi effects made by xnine

Bytebeats by xnine and FuxiProductions
---------------------------------------------------------------------------------------------------------------------------------------

!!Please do not maliciously run these kind of malwares on other peoples computers or public computers.!!

This malware can disable Task Manager and the Registry Editor and overwrite the MBR, so only run the safety version if you are on a real PC.
  ___ _   _ _  _     _ _____  __   _____  _   _ _ ___ ___    _____      ___  _   ___ ___ ___ _  ___ 
 | _ \ | | | \| |   /_\_   _| \ \ / / _ \| | | ( ) _ \ __|  / _ \ \    / / \| | | _ \_ _/ __| |/ / |
 |   / |_| | .` |  / _ \| |    \ V / (_) | |_| |/|   / _|  | (_) \ \/\/ /| .` | |   /| |\__ \ ' <|_|
 |_|_\\___/|_|\_| /_/ \_\_|     |_| \___/ \___/  |_|_\___|  \___/ \_/\_/ |_|\_| |_|_\___|___/_|\_(_)

##    ##  #######  ######## ########
###   ## ##     ##    ##    ##      
####  ## ##     ##    ##    ##      
## ## ## ##     ##    ##    ######  
##  #### ##     ##    ##    ##      
##   ### ##     ##    ##    ##      
##    ##  #######     ##    ########

VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV
Note: Make sure you install Windows Media Player, if not, the bytebeats will not play. So make sure
that Windows Media Player is installed before you run this. And also if you are using something else from the Source Code folder, Credit us.
--------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------
Epilepsy warning

It is likely to cause a seizure if you suffer from Epilepsy.
If you have Epilepsy, DO NOT TEST FOR YOU'RE OWN SAFETY!!
--------------------------------------------------------------------------------

Works in Windows XP (kinda) to Windows 11 (if you allow permissions for the GDI effects and the exes in Windows 11, 10, 8.1, and 8.)

Whole readme.txt by x1n3mot3
